# MemorableDay.in — Typography & Font Specification Guide

This guide details all the exact Google Fonts, typography pairings, weights, and CSS rules used across the **MemorableDay.in** universal social media downloader UI.

---

## 1. Quick Font Embed Codes

### HTML `<head>` Embed (Google Fonts CDN)
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@700;800;900&family=Plus+Jakarta+Sans:wght@600;700;800&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
```

### CSS `@import` Embed
```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@700;800;900&family=Plus+Jakarta+Sans:wght@600;700;800&family=Poppins:wght@500;600;700;800&display=swap');
```

---

## 2. Font Hierarchy & Usage Breakdown

| Font Name | Role & UI Placement | Weights Used | Google Fonts URL |
| :--- | :--- | :--- | :--- |
| **Outfit** | **Hero & Section Headings** (`DOWNLOAD ANYTHING`, `UNLIMITED DOWNLOADS FOR ALL`, `EXPLORE FAST & FREE MEDIA SAVING`, `10M+`, `99.9%`, `500K+`, `4K VIDEO`, `MP3 AUDIO`, `NO WATERMARK`, `INSTANT SAVE`) | `800 ExtraBold`<br>`900 Black` | https://fonts.google.com/specimen/Outfit |
| **Poppins** | **Original Reference Template & Accent Headings** (`TECHNOLOGY`, `APPROACH`, `Supported By :`, `MAGICAL PIXEL-BASED ART`) | `700 Bold`<br>`800 ExtraBold` | https://fonts.google.com/specimen/Poppins |
| **Plus Jakarta Sans** | **Brand Wordmark & Bento Feature Titles** (`MemorableDay.in`, `One-Click Paste`, `MP4 & MP3 Quality Selector`, `No Watermarks Ever`, `Trusted by millions worldwide`) | `700 Bold`<br>`800 ExtraBold` | https://fonts.google.com/specimen/Plus+Jakarta+Sans |
| **Inter** | **UI Controls, Inputs, Quality Pills & Body Text** (`Paste your media link here...`, `Download Now`, `MP4 Video`, `MP3 Audio`, `1080p Full HD`, `320kbps MP3`, `Save File`, `Supported Platforms:`) | `400 Regular`<br>`500 Medium`<br>`600 SemiBold`<br>`700 Bold` | https://fonts.google.com/specimen/Inter |

---

## 3. Tailwind CSS & Native CSS Variable Setup

### CSS Variables
```css
:root {
  --font-display: 'Outfit', 'Poppins', sans-serif;
  --font-heading: 'Plus Jakarta Sans', 'Inter', sans-serif;
  --font-body: 'Inter', sans-serif;
}
```

### Tailwind Config (`tailwind.config.js`)
```javascript
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        display: ['Outfit', 'Poppins', 'sans-serif'],
        heading: ['"Plus Jakarta Sans"', 'Inter', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
      },
      colors: {
        'brand-yellow': '#e2ff1a',
        'brand-cyan': '#0cf2ff',
        'brand-pink': '#ff47e2',
        'brand-blue': '#2b4eff',
        'brand-gold': '#c5892b',
      }
    }
  }
}
```

---

## 4. Package Contents Summary

```text
memorableday_assets.zip
├── FONTS.md                            # Complete font documentation and CSS setup (this file)
├── png_cutouts_transparent/           # 22 Transparent 32-bit RGBA PNG cutouts:
│   ├── logo_m.png                     # Circular 'M' brand logo mark
│   ├── o_play.png                     # 3D iridescent Play Orb ('O' in DO)
│   ├── o_globe.png                    # 3D iridescent Globe Orb ('O' in LOAD)
│   ├── hero_sculpture.png             # Central 3D liquid-chrome sculpture
│   ├── 3d_youtube.png                 # 3D floating YouTube button
│   ├── 3d_instagram.png               # 3D floating Instagram button
│   ├── 3d_tiktok.png                  # 3D floating TikTok badge
│   ├── 3d_facebook.png                # 3D floating Facebook badge
│   ├── 3d_pinterest.png               # 3D floating Pinterest badge (matching tilt)
│   ├── flat_youtube.png               # Flat YouTube platform icon
│   ├── flat_instagram.png             # Flat Instagram platform icon
│   ├── flat_tiktok.png                # Flat TikTok platform icon
│   ├── flat_facebook.png              # Flat Facebook platform icon
│   ├── flat_pinterest.png             # Flat Pinterest platform icon
│   ├── avatars_trio.png               # Overlapping 3-user avatar badge
│   ├── preview_thumb.png              # Popover media preview thumbnail card
│   ├── studio_sculpture.png           # Isolated Studio 3D liquid sculpture
│   ├── glass_mp4.png                  # 3D frosted-glass MP4 badge
│   ├── glass_mp3.png                  # 3D frosted-glass MP3 badge
│   ├── glass_tiktok.png               # 3D frosted-glass TikTok badge
│   ├── studio_card_full.png           # Full Studio 3D card assembly
│   └── no_watermark_icon.png          # Crossed-prism No Watermarks icon
└── high_res_original_renders/         # 24 Original 1024x1024 high-res master renders (JPEGs)
```
